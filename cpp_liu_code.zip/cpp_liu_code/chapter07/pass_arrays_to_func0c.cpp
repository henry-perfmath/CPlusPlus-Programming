/*
 * pass_arrays_to_func0c.cpp
 *
 *  Created on: Aug 3, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;
int reset (int *num, int size) {
	int sum = 0;
	for (int i = 0; i < size; i++) {
		num[i] = 0;
		cout << i << ' ' << sum << endl;
	}
	return sum;
}
int sum (int *num, int size) {
	int sum = 0;
	for (int i = 0; i < size; i++) {
		sum += num[i];
		cout << i << ' ' << sum << endl;
	}
	return sum;
}
int main () {
	int size = 10;
	int num [size];
	for (int i = 0; i < size; i++) {
		num [i] = i;
	}
	reset (num, size);
	cout << sum (num, size) << endl;
	return 0;
}



