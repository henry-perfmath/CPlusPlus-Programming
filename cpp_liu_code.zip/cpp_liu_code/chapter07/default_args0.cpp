/*
 * default_args0.cpp
 *
 *  Created on: Aug 3, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int divide (int x = 4, int y = 1) {return x / y;}

int main () {
	cout << " calling divide (30, 5): " << divide (30, 5) << endl;
	cout << " calling divide (10): " << divide (10) << endl;
	cout << " calling divide ( ): " << divide () << endl;
	return 0;
}
