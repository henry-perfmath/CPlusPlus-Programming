/*
 * pass_char_array_to_func0b.cpp
 *
 *  Created on: Aug 3, 2013
 *      Author: henry
 */
#include<iostream>
#include <cstring> // for strcpy
using namespace std;

char *get_substring (char sub[], char str[]) {
  // char *get_substring (char *sub, char *str) {
	int ch;
	char *p1, *p2, *start;
	for ( ch = 0; str [ch]; ch++) {
		p1 = &str [ch];
		start = p1;
		p2 = sub;
		while (*p2 && *p2 == *p1) {
			p1++;
			p2++;
		}
		if (!*p2) return start;
	}
	return 0;
}
int main () {
	int size = 80;
	char str [size];
	char sub_str [size];
	strcpy (str, "This is a test");
	strcpy (sub_str, "is");

	char *new_sub;
	new_sub = get_substring (sub_str, str);
	cout << "substring: " << sub_str << '-' << new_sub << endl;
	return 0;
}



