/*
 * overloading_func0.cpp
 *
 *  Created on: Aug 3, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int add_x_and_y (int x, int y) {return x + y;}
//double add_x_and_y (double x, double y) {return x + y;}

int main () {
	cout << " 1 + 1 = " << add_x_and_y (1, 1) << endl;
	cout << " 1.1 + 1.1 = " << add_x_and_y (1.1, 1.1) << endl;
	return 0;
}
