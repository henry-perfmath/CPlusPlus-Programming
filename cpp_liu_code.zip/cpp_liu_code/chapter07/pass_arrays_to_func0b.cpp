/*
 * pass_arrays_to_func0b.cpp
 *
 *  Created on: Aug 3, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int sum (int num[], int size) {
	int sum = 0;
	for (int i = 0; i < size; i++) {
		sum += num[i];
		cout << i << ' ' << sum << endl;
	}
	return sum;
}
int main () {
	int size = 10;
	int num [size];
	for (int i = 0; i < size; i++) {
		num [i] = i;
	}
	cout << sum (num, size) << endl;
	return 0;
}



