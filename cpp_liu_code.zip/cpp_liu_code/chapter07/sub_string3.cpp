/*
 * sub_string.cpp
 *
 *  Created on: Aug 3, 2013
 *      Author: henry
 */
#include<iostream>
#include <cstring> // for strcpy
using namespace std;

char *get_substring (char *sub, char *str) {
	int ch;
	char *p1, *p2, *start;
	for ( ch = 0; str [ch]; ch++) {
		p1 = &str [ch];
		start = p1;
		p2 = sub;
		while (*p2 && *p2 == *p1) {
			p1++;
			p2++;
		}

		if (!*p2) {
			cout << start << endl;
			return start;
		}
	}
	return 0;
}

char *get_substring3 (char *sub, char *str) {
	char *p1, *p2, *start;

	p1 = str;
	p2 = sub;

	while (*p1 != *p2 && *p2) {
		p1++;
	}

	start = p1;

	while (*p1 == *p2 && *p2) {
		p1++;
		p2++;
	}
	cout << *p1 << endl;
	if (!*p2) {
		return start;
	} else {
		return NULL;
	}
}

int main () {
	//char *str = "This is a test";
	//char *sub_str = "is";

	//char *str;
	char *sub_str2;

	char str[40];
	char sub_str[40];
	strcpy (str, "This is a test");
	cout << str << endl;
	strcpy (sub_str, "is a");

	//strcpy (sub_str2, get_substring (sub_str, str));
	sub_str2 = get_substring (sub_str, str);
	cout << "substring: " << sub_str2 << endl;
	return 0;
}



