/*
 * recursive.cpp
 *
 *  Created on: Aug 3, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

void reverse (char *str) {
	if (*str) reverse ( str + 1);
	else return;
	cout << *str;
}
int main (int argc, char *argv []) {
	char str [] = "test";
	reverse (str);
	return 0;
}
