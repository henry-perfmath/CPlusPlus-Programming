/*
 * string_array.cpp
 *
 *  Created on: Jul 28, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int main ( ) {
	char customers [ ][80] = {
			{"john smith, 123 anyway, any city, XX 99999, (999) 999 - 9999"},
			{"corte mandera, 456 anyway, any city, XX 88888, (888) 888 - 8888"},
			{"scooby doo, 789 anyway, any city, XX 77777, (777) 777 - 7777"}
	};

	for (int i = 0; i < 3; i++) {
		cout << customers [i] << endl;
	}
	return 0;
}



