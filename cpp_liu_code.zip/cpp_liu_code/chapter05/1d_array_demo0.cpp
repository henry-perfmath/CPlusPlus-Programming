/*
 * 1d_array_demo0.cpp
 *
 *  Created on: Jul 28, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>
using namespace std;

int main () {
	int array_size = 5;
	int k [array_size];

	for (int i = 0; i < array_size; i++) {
		k [i] = rand () % 100;
	}

	for (int i = 0; i < array_size; i++) {
		cout << "k[" << i << "] = " << k[i] << endl;
	}
	return 0;
}



