/*
 * char_array_demo0.cpp
 *
 *  Created on: Jul 28, 2013
 *      Author: henry
 */
#include<iostream>
#include<string>
#include<cstdio>
using namespace std;

void c_hello () {
	int array_size = 80;
	char hello [array_size];
	gets (hello);

	int index = 0;
	while (hello [index]) {
		cout << hello [index];
		index++;
	}
	cout << endl;
}
void cpp_hello () {

	string hello;
	//getline(cin, hello, ' ');
	getline(cin, hello);

	int index = 0;
	while (hello [index]) {
		cout << hello [index];
		index++;
	}
	cout << endl;
}
int main() {
	c_hello();
	cpp_hello();

	return 0;
}

