/*
 * 2d_array_demo0.cpp
 *
 *  Created on: Jul 28, 2013
 *      Author: henry
 */

#include<iostream>
#include<cstdlib>
using namespace std;

int main () {
	int row_size = 3;
	int column_size = 5;
	int k [row_size][column_size];

	for (int i = 0; i < row_size; i++) {
		for (int j = 0; j < column_size; j++) {
				k [i][j] = rand () % 100;
			}
	}

	for (int i = 0; i < row_size; i++) {
		for (int j = 0; j < column_size; j++) {
			cout << "k[" << i << "]" << "[" << j << "] = " << k[i][j] << '\t';
			}
		cout << endl;
	}
}


