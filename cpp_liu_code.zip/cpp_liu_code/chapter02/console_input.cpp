/*
 * console_input.cpp
 *
 *  Created on: Jul 21, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;
int main () {
	float wage = 62.5; // hourly
	float hours;
	float pay;

	cout << "Enter the number of hours you worked this week:";
	cin >> hours;
	pay = wage * hours; // assuming 20 dollars per hour
	cout << "You have made $" << pay << " this week!\n";
	return 0;
}



