/*
 * dynamic_memory1.cpp
 *
 *  Created on: Aug 11, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstring>
using namespace std;

struct istr {
	int i;
	char str [80];
};

class y {
	istr *p;
public:
	y (int i, char []);
	y (const y &y0);
	~y ();
	istr get_ich () {return *p;}
	int get_i () {return p->i;}
	char *get_str () {return p->str;}
};
y::y (int i, char s[]) {
	 cout << "calling constructor to allocate memory for p" << endl;
	 p = new istr;
	 p->i = i;
	 strcpy (p->str, s);
 }
y::y (const y &y0) {
	p = new istr;
	*p = *y0.p;
	cout << "copy constructor called" << endl;
}
y::~y () {
	cout << "calling destructor to delete p" << endl;
	delete p;
}
void print_y (y y0) {
	cout << y0.get_i () << " " << y0.get_str () << endl;
}

int main () {
	char s0 [80];
	strcpy (s0, "This is a test");
	y y0 (100, s0);
	print_y (y0);

	return 0;
}
