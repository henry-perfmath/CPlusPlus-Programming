/*
 * class_inline0.cpp
 *
 *  Created on: Aug 10, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class x {
	int i;
	char ch;
public:
	x (int k = 0, char c = 'x') {		// constructor
		set_i (k);
		set_ch (c);
		cout << "x has been initialized with i = " << i
			 << " and ch = " << ch << endl;
	}
	~x () {		// destructor
		cout << "x has been destroyed\n";
	}
	int get_i ();
	char get_ch () {return ch;}
	void set_i (int k) {i = k;}
	void set_ch (char c) {ch = c;}
};
inline int x::get_i () {return i;}
int main () {
	x x0;
	x x1 (101, 'b');
	x x2 = x (102, 'c');
	x1.set_i (103);
	x1.set_ch ('d');
	cout << x0.get_i () << " " << x0.get_ch() << endl;
	cout << x1.get_i () << " " << x1.get_ch() << endl;
	cout << x2.get_i () << " " << x2.get_ch() << endl;
	return 0;
}
