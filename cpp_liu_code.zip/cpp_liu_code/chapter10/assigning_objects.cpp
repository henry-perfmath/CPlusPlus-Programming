/*
 * assigning_objects.cpp
 *
 *  Created on: Aug 10, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class x {
	int i;
	char ch;
public:
	x (int i = 0, char ch = 'x') {		// constructor
		this->i = i;
		this->ch = ch;
		cout << "x has been initialized with i = " << this->i
			 << " and ch = " << this->ch << endl;
	}
	~x () {		// destructor
		cout << "x has been destroyed\n";
	}
	int get_i () {return i;}
	char get_ch () {return ch;}
	void set_i (int k) {i = k;}
	void set_ch (char c) {ch = c;}
};

int main () {
	x x0 (100, 'a');
	x x1 (200, 'b');

	cout << "prior to assigning x0 to x1:" << endl;
	cout << "x0: " << x0.get_i () << " " << x0.get_ch () << endl;
	cout << "x1: " << x1.get_i () << " " << x1.get_ch () << endl;

	x1 = x0;
	cout << "\nafter assigning x0 to x1:" << endl;
	cout << "x0: " << x0.get_i () << " " << x0.get_ch () << endl;
	cout << "x1: " << x1.get_i () << " " << x1.get_ch () << endl;

	return 0;
}
