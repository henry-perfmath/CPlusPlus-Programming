/*
 * pointers_to_objects.cpp
 *
 *  Created on: Aug 10, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class x {
	int i;
	char ch;
public:
	x (int k = 0, char c = 'x') {		// constructor
		set_i (k);
		set_ch (c);
		cout << "x has been initialized with i = " << i
			 << " and ch = " << ch << endl;
	}
	~x () {		// destructor
		cout << "x has been destroyed\n";
	}
	int get_i () {return i;}
	char get_ch () {return ch;}
	void set_i (int k) {i = k;}
	void set_ch (char c) {ch = c;}
};
void print_x (x &obj_x, int i) {
	cout << "x_array[" << i << "]: " << obj_x.get_i ()
				 << " " << obj_x.get_ch() << endl;
}
int main () {
	x x_array [3] = {x (0, 'a'), x (1, 'b'), x (2, 'c')};
	x *p;
	p = x_array;

	for (int i = 0; i < 3; i++, p++) {
		p-> set_i (p->get_i () + i);
		p-> set_ch (p-> get_ch () + i);
	}

	for (int i = 0; i < 3; i++) {
		print_x (x_array[i], i);
	}
	return 0;
}
