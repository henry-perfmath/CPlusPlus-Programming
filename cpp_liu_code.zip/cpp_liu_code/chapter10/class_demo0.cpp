/*
 * class_demo0.cpp
 *
 *  Created on: Aug 10, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class x {
	int i;
	char ch;
public:
	int get_i ();
	char get_ch ();
	void set_i (int i);
	void set_ch (char ch);
	//int j;
};

int x::get_i () {
	return i;
}
char x::get_ch () {
	return ch;
}
void x::set_i (int k) {
	i = k;
}
void x::set_ch (char c) {
	ch = c;
}

int main () {
	x x0;
	x0.set_i (100);
	//x0.i = 100;
	x0.set_ch ('a');
	//x0.ch = 'a';
	cout << x0.get_i () << " " << x0.get_ch() << endl;
	//x0.j = 200;
	//cout << x0.j << endl;
	return 0;
}
