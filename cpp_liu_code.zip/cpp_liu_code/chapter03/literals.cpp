/*
 * literals.cpp
 *
 *  Created on: Jul 21, 2013
 *      Author: henry
 */
#include <iostream>
using namespace std;
int main()
{
	char ch1 = 'j';
	char ch2 = 106;
	string str = "j";

	int int_dec = 106;
	int int_hex = 0x6A;
	int int_oct = 0152;

	cout << ch1 << " " << ch2 << " " << str << "\n"
	     << int_hex << " " << int_dec << " "
	     << int_oct << endl;
    return 0;
}
