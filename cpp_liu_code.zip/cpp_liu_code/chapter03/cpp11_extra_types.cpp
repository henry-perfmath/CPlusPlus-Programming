/*
 * cpp11_extra_types.cpp
 *
 *  Created on: Jul 23, 2013
 *      Author: henry
 */
#include <iostream>
#include <limits>
using namespace std;

int main()
{
    // C++11 char16_t, char32_t, long long int, and unsigned long long int
	cout << "size of char16_t: " << sizeof (char16_t) << '\n';
	cout << "size of char32_t: " << sizeof (char32_t) << '\n';
	cout << "size of long long int: " << sizeof (long long int) << '\n';
	cout << "size of unsigned long long int: " << sizeof (unsigned long long int) << '\n';
    return 0;
}
