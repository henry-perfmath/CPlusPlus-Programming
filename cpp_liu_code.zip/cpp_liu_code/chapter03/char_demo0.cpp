/*
 * auto_demo.cpp
 *
 *  Created on: Jul 21, 2013
 *      Author: henry
 */
#include <iostream>
#include <chrono>
using namespace std;
using namespace std::chrono;
auto t0 = high_resolution_clock::now();
int main()
{
	// numbers 0 - 9
	for (char c = 48; c < 58; c++) {
		cout << c << " ";
	}
	cout << endl;
	// UPPER CASE LETTERS A - Z
	for (char c = 65; c < 91; c++) {
		cout << c << " ";
	}
	cout << endl;
	// lower case letter a - z
	for (char c = 97; c < 123; c++) {
		cout << c << " ";
	}
    return 0;
}
