/*
 * struct_demo1.cpp
 *
 *  Created on: Aug 7, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstring>
using namespace std;

struct account_t {
	char type [12];
	double balance;
	int status;
};
int main() {
	account_t checking;
	account_t *p;
	p = &checking;

	strcpy(p->type, "checking");
	p->balance = 100.5;
	p->status = 1;

	cout << p->type << " " << p->balance
		 << " " << p->status <<endl;
	return 0;
}
