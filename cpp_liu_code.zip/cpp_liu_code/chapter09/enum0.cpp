/*
 * enum0.cpp
 *
 *  Created on: Aug 5, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int main() {
	enum us_states {
		VA, WA, CA
	};

	us_states state;
	state = VA;
	cout << state << endl;
	state = WA;
	cout << state << endl;
	state = CA;
	cout << state << endl;

	int i;
	do {
		cout << "Enter a number between 0 - 2 (or -1 to quit): ";
		// cin >> state; //error: no match for �operator>>� in �std::cin >> state�
		cin >> i;
		// state = i;	// error: invalid conversion from �int� to �main()::us_states�
		state = (us_states) i;
		// switch (i) { // this will also work
		switch (state) {
		case VA:
			cout << "Virginia" << endl;
			break;
		case WA:
			cout << "Washington" << endl;
			break;
		case CA:
			cout << "California" << endl;
			break;
		default:
			cout << "unknown state" << endl;
			break;
		}
	} while (state >= 0); // exit if a negative integer is entered
}

