/*
 * bst.c
 *
 *  Created on: Feb 13, 2018
 *      Author: henryliu
 */

#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
    int key;
    struct node *left, *right;
} Node;


Node *make_node(int item);
void inorder(Node *node);
void preorder(Node *node);
void postorder(Node *node);
Node *insert(Node *node, int key);
void clear (Node *node);
