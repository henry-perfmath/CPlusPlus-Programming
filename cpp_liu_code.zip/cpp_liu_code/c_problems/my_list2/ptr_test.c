/*
 * ptr_test.c
 *
 *  Created on: Feb 16, 2018
 *      Author: henryliu
 */

#include <stdio.h>
#include <stdlib.h>

void change_ptr(int *x, int z) {
	int *y = x;
	*y = 1234;
	*x += 1000;
	z = 5678;
}

int main() {
	int *x;
	*x = 100;

	int z = 10;

	printf("before: x = %d, z = %d\n", *x, z);
	change_ptr(x, z);
	printf("after: x = %d, z = %d\n", *x, z);

	return 0;
}
