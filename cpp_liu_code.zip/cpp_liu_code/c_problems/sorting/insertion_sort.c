/*
 * insertion_sort.cpp
 *
 *  Created on: Sep 5, 2013
 *      Author: henry
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const int MAX_ARRAY_SIZE = 10;
//pattern: use a for loop on data array and a while loop for doing the work
void insertion_sort2(int a[], int N) {
	for (int i = 1; i < N; ++i) {
		int cursor = i;
		while (cursor > 0 && a[cursor - 1] > a [cursor]) {
			// swap and decrement tmp index
			int tmp = a [cursor];
			a[cursor] = a[cursor - 1];
			a[cursor - 1] = tmp;
			--cursor;
		}
	}
}

//slightly faster by moving a[i] to its position in one go
void insertion_sort(int a[], int N) {
	for (int i = 1; i < N; ++i) {
		int cursor = i;
		int curr_item = a[i];
		while (cursor >= 0 && a[cursor - 1] > curr_item) {
			a[cursor] = a[cursor - 1];
			// no need to swap as the curr_item has been saved
			--cursor;
		}
		a[cursor] = curr_item;
	}
}

int main() {
	srand(time(0));
	printf("before sorting:\n");
	int a[MAX_ARRAY_SIZE];
	for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
		a[i] = rand() % 30;
		(i < (MAX_ARRAY_SIZE - 1)) ? printf("%d ", a[i]) : printf("%d \n", a[i]);
	}
	insertion_sort(a, MAX_ARRAY_SIZE);
	printf("after sorting:\n");
	for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
		(i < (MAX_ARRAY_SIZE - 1)) ? printf("%d ", a[i]) : printf("%d \n", a[i]);
	}

	return 0;
}
