/*
 * itoa.cpp
 *
 *  Created on: Sep 6, 2013
 *      Author: henry
 */

#include <stdio.h>
#include <string.h>

void swap(char *x, char *y) {
	char tmp;
	tmp = *x;
	*x = *y;
	*y = tmp;
}

void itoa(int n, char *buf) {
	// keep the original for sign info
	int n0 = n;
	if (n0 < 0)
		n = -n;

	// cursor - buf array cursor and length
	int cursor = 0;
	do {
		buf[cursor++] = n % 10 + '0';
	} while ((n /= 10) > 0);

	// add sign if negative
	if (n0 < 0)
		buf[cursor++] = '-';

	// null-end the string
	buf[cursor] = '\0';

	// reverse it
	for (int i = 0; i < cursor / 2; i++)
		swap(&buf[i], &buf[cursor - i - 1]); // takes address, not value
}

int main() {

	int i;
	char buf[9];
	do {
		printf("Enter an integer (positive or negative or 0 to exit): ");
		scanf("%d", &i);
		itoa (i, buf);
		printf("number %d converted to %s\n:", i, buf);
	} while (i != 0);
	return 0;
}

