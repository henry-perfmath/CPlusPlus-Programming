/*
 * reverse_string.cpp
 *
 *  Created on: Sep 6, 2013
 *      Author: henry
 */

#include <stdio.h>
#include <string.h>

void reverse1(char *str);
void reverse2(char *str);
void swap(char *x, char *y);

int main() {
	char str[20] = "This is a test";
	char original[20];
	strcpy(original, str);

	printf("initial: %s\n", str);
	reverse2 (str);

	printf("afetr: %s <==>%s\n", str, original);
	return 0;
}

// mirroring swapping
// c version: must pass in address via &. different from c++
void reverse1(char *str) {
	int size = strlen (str);
	for (int i = 0; i < size / 2; i++) swap (&str[i], &str [size - i - 1]);

}
// pointer arithmetic
void reverse2(char *str) {
	char *end = str;

	if (str) {
		// move end to the end
		while (*end) {
			++end;
		}
		--end; // back up one
		printf("str=%s, end=%s\n", str, end);

		char tmp;
		while (str < end) {
			tmp = *str;
			*str++ = *end;
			*end-- = tmp;
		}
		printf("str=%s, end=%s\n", str, end);
	}
}

void swap(char *x, char *y) {
	char tmp;
	tmp = *x;
	*x = *y;
	*y = tmp;
}





