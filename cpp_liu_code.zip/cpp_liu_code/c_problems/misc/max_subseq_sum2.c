/*
 * max_subseq_sum2.cpp
 *
 *  Created on: Oct 14, 2013
 *      Author: hliu
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int max_subsequence_sum(const int a[], const unsigned int n) {
	int sum = 0, max_sum = 0;
	for (int i = 0; i < n; i++) {
		sum += a[i];

		if (sum > max_sum) {
			max_sum = sum;
		} else if (sum < 0) {
			sum = 0;
		}
	}
	return max_sum;
}

int main() {
	int n = 0;
	printf("enter n:");
	scanf("%d", &n);
	srand(time(NULL));
	int a[n];
	a[0] = -5;
	for (int i = 1; i < n; i++) {
		a[i] = 20 / 2 - rand() % 20;
	}

	for (int i = 0; i < n; i++) {
		(i < (n - 1)) ? printf("%d ", a[i]) : printf("\n");
	}

	int result = max_subsequence_sum(a, n);
	printf("result = %d\n", result);

	return 0;
}

