/*
 * sub_string.cpp
 *
 *  Created on: Aug 3, 2013
 *      Author: henry
 */
#include <stdio.h>
#include <string.h>

char *get_substring(char *sub, char *str) {
	char *p1, *p2, *start;
	// move char by char sequentially
	for (int ch = 0; str [ch]; ch++) {
		p1 = &str [ch]; // p1 gets the address
		start = p1;     // set start to p1 for returning the substring found
		p2 = sub; 		// p2 points to the input sub string

		// check if sub string found
		while (*p2 && *p2 == *p1) {
			p1++;
			p2++;
		}

		printf("ch=%d, str[ch] =%c, p1 =%s, p2=%s, start = %s\n", ch, str[ch], p1, p2, start);
		// if p2 is found, return start
		if (!*p2) return start;
	}
	return strcat(sub, " not found\n");
}
int main() {
	//option 1
	//char *str = "This is a test";
	//char *sub_str = "is";

	//option 2
	//char str[] = "This is a test";
	//char *sub_str = "is";

	// option 3
	char str [30];
	char sub_str [30];
	strcpy(str, "This is a test");
	char sub_string_found[30];
	do {
		printf("enter a substring or return to exit:");
		//scanf("%s", sub_str); // does not read whitespaces
		gets(sub_str);
		printf("You entered %s with length = %ld\n", sub_str, strlen(sub_str));
		/*
		 * char sub_string_found[]; needs a size
		 * char sub_string_found[30]; not assignable. must use strcpy
		 */
		strcpy(sub_string_found, get_substring (sub_str, str));
		printf("substring: %s\n", sub_string_found);
	} while (strlen(sub_str) > 0);
	return 0;
}



