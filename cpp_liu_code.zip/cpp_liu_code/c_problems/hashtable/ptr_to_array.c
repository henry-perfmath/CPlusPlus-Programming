/*
 * ptr_to_array.c
 *
 *  Created on: Feb 14, 2018
 *      Author: henryliu
 */
#include <stdio.h>
#include <stdlib.h>

int main() {
	int *ptr;
	int SIZE = 10;
	ptr = (int *) malloc(sizeof(int) * SIZE);

	if (!ptr) {
		printf("allocating memory failed:\n");
		return -1;
	}

	for (int i = 0; i < SIZE; i++) {
		ptr[i] = i;
	}

	for (int i = 0; i < SIZE; i++) {
		(i < SIZE - 1) ? printf("%d ", ptr [i]) : printf(" %d \n", ptr [i]);
	}
	free(ptr);
	// do not do this unless it is a double pointer
	/*
	for (int i = 0; i < SIZE; i++) {
		free (&ptr[i]);
	}
	*/
}

