/*
 * hashtable_demo0.c
 *
 *  Created on: Feb 14, 2018
 *      Author: henry
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
const int TABLE_CAPACITY = 5;

typedef struct entry {
	int key;
	int value;
	struct entry *next;
} Entry;

// a hash list is a linear list indexed with hash values of the entries
typedef struct table{
    int capacity;
    struct entry **hash_list;
} Table;

Table *init(int capacity) {
	Table *tbl = (Table *)malloc(sizeof(Table));
	tbl->capacity = capacity;
	tbl->hash_list = (Entry **)malloc(sizeof(Entry)*capacity);

    for(int i = 0;i < capacity;i++)
    		tbl->hash_list[i] = NULL;
    return tbl;

}

int get(const Table *table, int key) {
	int hash = (key % TABLE_CAPACITY);
	Entry *cursor = table->hash_list[hash];
	// no need to have another pointer
	while (cursor) {
		if (cursor->key == key) {
			return cursor->value;
		}
		cursor = cursor->next;
	}
	return -1;
}

int get_all_by_hash(const Table *table, int key) {
	int hash = (key % TABLE_CAPACITY);
	Entry *cursor = table->hash_list[hash];
	while (cursor) {
		printf("(%d, %d) ", cursor->key, cursor->value);
		cursor = cursor->next;
	}
	return -1;
}

void put(Table *table, int key, int value) {
	int hash = (key % TABLE_CAPACITY);
	Entry *new_entry = (Entry *)malloc(sizeof(Entry));
	new_entry->key = key;
	new_entry->value = value;
	new_entry->next = NULL;

	Entry *curr = table->hash_list[hash];
	//1. check if the first at the hashed cell
	if (curr == NULL) {
		table->hash_list[hash] = new_entry;
		return;
	}

	Entry *cursor = curr;
	while (cursor){
		if (cursor->key == key) {
			cursor->value = value;  // update
			return;
		}
		//break if cursor is the last non-null node
		if (cursor->next == NULL) break;
		cursor = cursor->next;
	};

	// 2. put at the end of the hashed list
	//cursor->next = new_entry;

	// 3. put at the front
	new_entry->next = curr;
	table->hash_list[hash] = new_entry;
}

void delete(Table *table) {
	Entry *cursor = *table->hash_list;
	while (cursor) {
		Entry *psave_next = cursor->next;
		free (cursor);
		cursor = psave_next;
	}
	free (table);
}

int main() {
	unsigned int cycle;
	//unsigned int max_cycles = 5000000;
	unsigned int max_cycles = 10;
	int test_key = 3;
	int test_value;
	long start, end;

	int cache_size = 10;
	start = clock() * 1000 / CLOCKS_PER_SEC;
	cycle = 1;
    Table *hash_table = init(TABLE_CAPACITY);

	while (cycle < max_cycles) {
		for (int i = 0; i < cache_size; i++) {
			put(hash_table , i * cycle, 100 * i * cycle);
		}
		cycle++;
	}
	// retrieve from cache
	test_value = get(hash_table , test_key);
	printf("test_key = %d for test_value = %d\n", test_key, test_value);
	get_all_by_hash(hash_table, 3);
	delete(hash_table);
	end = clock() * 1000 / CLOCKS_PER_SEC;
	printf("table time: %d\n", (int) (end - start));

	return 0;
}
