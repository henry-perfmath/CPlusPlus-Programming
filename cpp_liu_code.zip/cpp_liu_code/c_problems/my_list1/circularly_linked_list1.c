/*
 * circularly_linked_list.c
 *
 *  Created on: Feb 14, 2018
 *      Author: henry
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "my_list1.h"

void display (Item item) {
	printf("%d ", item.data);
}

void fold(int position, Node *list) {
	printf("\ncalling fold at position = %d ", position);
	Node* cursor = list;
	Node* fold_ptr;
	int count = 1;
	while (cursor->next != NULL) {
		if (count == position) {
			//do not do *ptr = *curr
			fold_ptr = cursor;
			printf("folding at %d \n", cursor->item.data);
		} else {
			printf("skip folding at %d for %d \n", count, cursor->item.data);
		}
		cursor = cursor->next;
		count++;
	}

	printf("assigning folding fold_ptr at %d ", fold_ptr->item.data);
	cursor->next = fold_ptr;
}

void check_circular_linked_list(const Node *list) {
	// seg 0: declare fast and slow pointers
	const Node *fast = list;
	const Node *slow = list;

	// seg 1: move both pointers. Break if they meet
	printf("find meeting point ...\n");
	while (fast != NULL && fast->next != NULL) {
		slow = slow->next;
		fast = fast->next;
		fast = fast->next;
		if (slow == fast) break;
	}

	// seg 2: no loop if fast or fast->next NULL
	if (fast == NULL || fast->next == NULL) return;
	printf("circular linked list meeting point: %d\n", slow->item.data);

	// seg 3: find entry point for circular linked list
	printf("\nfind entry point for circular linked list...\n");
	slow = list;
	while (slow != fast) {
		slow = slow->next;
		fast = fast->next;
	}
	printf("circular linked list entry point: %d\n", fast->item.data);
}

int main() {

	// create an empty list
	Node *head = NULL;
    const Node *head_const = head;

    if (is_full())
    {
        fprintf(stderr,"No memory available! Bye!\n");
        exit(1);
    }

	int SIZE = 19;
	for (int i = 0; i < SIZE; i++) {
		Item temp;
		temp.data = i + 1;
		printf("insert %d\n", temp.data);
		insert (temp, &head);
	}

	traverse (&head_const, display);
	fold (12, head);

	printf("calling check_circular_linked_list:\n");
	check_circular_linked_list (head);
	clear_circular(&head, SIZE);
	return 0;
}

