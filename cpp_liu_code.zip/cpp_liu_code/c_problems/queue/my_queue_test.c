#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "my_queue.h"

void display(Item item); // local
void check_queue(Queue queue);
int main(void)
{
    Queue queue;
    init(&queue);

    Item temp;

    temp.data = 10;
    printf("enqueue %d\n", temp.data);
    enqueue(temp, &queue);

    temp.data = 20;
    printf("enqueue %d\n", temp.data);
    enqueue(temp, &queue);

    temp.data = 30;
    printf("enqueue %d\n", temp.data);
    enqueue(temp, &queue);

    	printf("current size of the queue:  %d\n", queue_length(&queue));
    	check_queue(queue);

    	printf("dequeue ...\n");
    if (	dequeue(&temp, &queue)) {
    		printf("dequeued: %d\n", temp.data);
    }
    	check_queue(queue);
    clear(&queue);

    return 0;
}
void check_queue(Queue queue) {
    if (is_empty(&queue)) {
        printf("No data entered. ");
    } else {
        printf ("Contents of the queue: ");
        traverse(&queue, display);
        printf ("\n");
    }
}
void display(Item item)
{
    printf("%d ", item.data);
}

