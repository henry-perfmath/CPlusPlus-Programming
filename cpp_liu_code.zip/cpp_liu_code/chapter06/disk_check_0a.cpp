/*
 * disk_check_0a.cpp
 *
 *  Created on: Jul 30, 2013
 *      Author: henry
 */

#include <iostream>
#include <cstdlib> // exit needs this on Linux
#include <fstream>
#include <string>
#include <sys/timeb.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <sstream>
using namespace std;

void readWriteTest(string fileName);
string getFilePostfix ();
void printLastKLines (char *fileName, int k);

string currentDateTime();
long getMilliCount();
long getMilliSpan(long nTimeStart);
long getFileSize(string fileName);

int main(int argc, char *argv[]) {

	string fileName = argv[1];
	if (fileName.find("ioTest2" > 0)) {
		printLastKLines ((char *)fileName.c_str(), 5);
	}
	readWriteTest("./" + fileName);
	return 0;
}

void readWriteTest(string fileName) {

	ifstream inFileStream(fileName.c_str());
	if (!inFileStream.is_open()) {
		cout << "Unable to open file "<< fileName << endl;
		exit(1);
	}
	string currTime = currentDateTime();
    cout << "current time: " << currTime << endl;

	string outFileName = fileName + "_" + getFilePostfix();

	ofstream outFileStream(outFileName.c_str());

	if (!outFileStream.is_open()) {
		cout << "Unable to open file " << outFileName << endl;
		exit(1);
	}

	string line;
	int count = 0;
	long totalReadTime = 0;
	long totalWriteTime = 0;
	long startTime = getMilliCount();

	do {
			int readStartTime = getMilliCount();
			getline(inFileStream, line);
			totalReadTime += getMilliSpan(readStartTime);

			int writeStartTime = getMilliCount();
			outFileStream << line;
			totalWriteTime += getMilliSpan(readStartTime);
			count++;

	} while (inFileStream.good());

	if (inFileStream.is_open()) {
		inFileStream.close();
	}
	if (outFileStream.is_open()) {
		outFileStream.close();
	}

	long fileSize = getFileSize(fileName);
	cout << "test data file size = " << fileSize * 0.000001 << " MB" << endl;
	cout << "total time = " << getMilliSpan(startTime)/1000.0 << " seconds" << endl;
	cout << "# of reads = # of writes = " << count << endl;
	cout << "total read time (ms) = " << totalReadTime << endl;
	cout << "average time (ms) per read = " << totalReadTime / (float) count << endl;
	cout << "total write time (ms) = " << totalWriteTime << endl;
	cout << "average time (ms) per write = " << totalWriteTime / (float) count << endl;
	cout << "read is " << totalWriteTime / (float) totalReadTime
			<< " times faster than write" << endl;
	cout << "read throughput on this drive: "
			<< (0.001 * fileSize / totalReadTime) << " MB/second" << endl;
	cout << "write throughput on this drive: "
			<< (0.001 * fileSize / totalWriteTime) << " MB/second" << endl;

}
// Get current date/time, format is YYYY-MM-DD.HH:mm:ss
string currentDateTime() {
	time_t now = time(0);
	struct tm tstruct;
	char buf[80];
	tstruct = *localtime(&now);
	// Visit http://www.cplusplus.com/reference/clibrary/ctime/strftime/
	// for more information about date/time format
	strftime(buf, sizeof(buf), "%Y-%m-%d_%X", &tstruct);

	return buf;
}
long getMilliCount() {
	timeb tb;
	ftime(&tb);
	long nCount = tb.millitm + (tb.time & 0xfffff) * 1000;
	return nCount;
}

long getMilliSpan(long nTimeStart) {
	long nSpan = getMilliCount() - nTimeStart;
	if (nSpan < 0)
		nSpan += 0x100000 * 1000;
	return nSpan;
}

long getFileSize(string fileName) {
	struct stat stat_buf;
	int rc = stat(fileName.c_str(), &stat_buf);
	return rc == 0 ? stat_buf.st_size : -1;
}

string getFilePostfix () {
	stringstream ss;
	ss << getMilliCount();
	return ss.str();
}

void printLastKLines (char *fileName, int k) {
	cout << "print last " << k << "lines\n";
	string lines [k];
	int size = 0;

	ifstream file (fileName);
	while (file.good()) {
		getline (file, lines[size %k]);
		size++;
	}

	int start = size > k ? (size % k) : 0;
	int count = min (k, size);

	for (int i = 0; i < count; i++) {
		cout << i << ": " << lines [(start +i) % k] << endl;
	}
}




