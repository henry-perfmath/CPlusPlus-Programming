/*
 * pointer_mistake2.cpp
 *
 *  Created on: Aug 2, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int main () {
	char *ptr = NULL;
	{
	    char ch = 'x';
	    ptr = &ch;
	}
	cout << *ptr << endl;
}



