/*
 * tokenizer_array_based.cpp
 *
 *  Created on: Jul 30, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdio>
using namespace std;

#include<iostream>
#include<cstdio>
using namespace std;
char str [256];
char token [10][80];

void tokenize ( ) {
		int index, j;
		index = -1;
		for (int i = 0; str [i] != '\0'; i++) {
			index++;
			for (j = 0; str [i] != ' ' && str [i]; j++, i++) {
				token [index][j] = str [i];
			}
			if (str[i] == ' ') token [index][j] = '\0';
			cout << token [index] << endl;
		}
}

int main () {
	cout << "enter a string:";
	gets (str);
	tokenize ();
	cout << "print tokens:\n";

	int i = 0;
	while (token[i][0]) {
		cout << "token [" << i << "] = " << token [i][0] << endl;
		i++;
	}

	return 0;
}





