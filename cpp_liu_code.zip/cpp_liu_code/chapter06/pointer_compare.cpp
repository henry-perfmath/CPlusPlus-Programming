#include <iostream>
using namespace std;

int main() {
	int i = 10;
	int j = 20;
	int *int_ptr1 = &i;
	int *int_ptr2 = &j;
	cout << int_ptr1 << ' ' << int_ptr2 << endl;

	if (int_ptr1 > int_ptr2) {
		cout << "int_ptr1 > int_ptr2" << endl;
	}
	if (int_ptr1 < int_ptr2) {
		cout << "int_ptr1 < int_ptr2 are equal" << endl;
	}
	if (int_ptr1 == int_ptr2) {
		cout << "int_ptr1 == int_ptr2 are equal" << endl;
	}
	if (int_ptr1 == int_ptr2) {
		cout << "int_ptr1 == int_ptr2 are equal" << endl;
	}
	if (int_ptr1 != int_ptr2) {
		cout << "int_ptr1 != int_ptr2 are equal" << endl;
	}

	return 0;
}
