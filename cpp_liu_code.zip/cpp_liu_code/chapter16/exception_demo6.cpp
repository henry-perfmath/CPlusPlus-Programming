/*
 * exception_demo6.cpp
 *
 *  Created on: Aug 20, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>
using namespace std;
void throw_it(int number) {
	int i = 99;
	float f = 123.123;
	const char str[80] = "This is a test!";
	try {
		if (number == 1) {
			throw i;
		} else if (number == 2) {
			throw f;
		} else if (number == 3) {
			throw str;
		} else {
			throw false;
		}
	} catch (int i) {
		cout << "In throw_it: caught an integer " << i;
	} catch (float f) {
		cout << "In throw_it: caught a float " << f;
	} catch (const char *s) {
		cout << "In throw_it: caught a str " << s;
	} catch (...) {
		cout << ". Rethrow ... " << endl;
		throw;
	}
}
int main() {
	int number;
	srand (time(NULL));
	while (true) {
		number = rand() % 4 + 1;
		cout << "\nnumber = " << number << ". ";
		try {
			throw_it (number);
		} catch (bool try_again) {
			cout << "Caught a bool type rethrown in throw_it for number = "
				 << number << ". Game over." <<endl;
			if (!try_again) exit(-1);
		} catch (...) {
			cout << "caught an unhandled exception.\n";
			exit (-1);
		}
	}
	return 0;
}

