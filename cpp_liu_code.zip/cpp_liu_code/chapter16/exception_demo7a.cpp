/*
 * exception_demo7a.cpp
 *
 *  Created on: Aug 29, 2013
 *      Author: henry
 */
#include <iostream>
#include<cstdlib>
#include <new>
using namespace std;
int main (int argc, char *argv[]) {
  int* int_array;
  int size = atoi (argv[1]);
  try {
    int_array= new int[size];
  } catch (bad_alloc &ba) {
    cerr << "bad_alloc caught: " << ba.what() << '\n';
  }
  if (!int_array) delete[] int_array;
  return 0;
}



