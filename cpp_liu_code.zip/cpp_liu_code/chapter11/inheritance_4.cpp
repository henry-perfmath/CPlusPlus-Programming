/*
 * inheritance_4.cpp
 *
 *  Created on: Aug 13, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;
class account {
	double balance;
	int status;
	bool joint;
protected:
	bool is_joint () {return joint;}
public:
	account (double balance, int status, bool joint) {
		this->balance = balance;
		this->status = status;
		this->joint = joint;
		cout << "base class account's constructor called" << endl;
	}
	~account () {cout << "base class account's destructor called" << endl;}
	double get_balance () {return balance;}
	int get_status () {return status;}
	void set_balance (double b) {balance = b;}
	void set_status (int i) {status = i;}
	void set_joint (bool j) {joint = j;}
};
class savings_account : public account {
	double interest_rate;
public:
	savings_account (double interest_rate,
		double balance, int status, bool joint) : account (balance, status,joint) {
		this->interest_rate = interest_rate;
		cout << "savings_account: constructor called" << endl;
	}
	~savings_account () {cout << "savings_account: destructor called" << endl;}
	double get_interest_rate () {return interest_rate;}
	void set_interest_rate (double rate) {interest_rate = rate;}
	void show_account () {
		cout << "status: " << get_status ()
			 << "\nbalance: " << get_balance ()
			 << "\ninterest rate: " << get_interest_rate ()
			 << "\nis_joint: " << is_joint () << endl;
	}
};

class super_savings_account : public savings_account {
public:
	super_savings_account (double interest_rate,
		double balance, int status, bool joint) : savings_account (interest_rate,
				balance, status, joint){
		cout << "super_savings_account: constructor called\n" << endl;}
	~super_savings_account () {
		cout << "\nsuper_savings_account: destructor called" << endl;
	}
};
int main () {
	super_savings_account super_savings (0.015, 100.0, 1, 1);
	super_savings.show_account ();
	return 0;
}



