/*
 * const_demo0.cpp
 *
 *  Created on: Jul 30, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

const int size = 9;

void my_swap1 (const int &x, const int &y) {
	int temp;
	temp = x;
	x = y; 		//error: assignment of read-only reference �x�
	y = temp;	//error: assignment of read-only reference �y�
}
void my_swap2 (const int *x, const int *y) {
	int *temp;
	*temp = *x;
	*x = *y; 	//error: assignment of read-only location �* x�
	*y = *temp;	//error: assignment of read-only location �* y�
}
int main () {
	size = 10;	//error: assignment of read-only variable �size�

	int x = 1;
	int y = 2;
	cout << "before swapping: x = " << x << " y = " << y << endl;

	my_swap1 (x, y);
	cout << "after swapping: x = " << x << " y = " << y << endl;

	my_swap2 (&x, &y);
	cout << "after swapping: x = " << x << " y = " << y << endl;
	return 0;
}
