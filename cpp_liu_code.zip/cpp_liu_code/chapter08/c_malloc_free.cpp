/*
 * new_delete0.cpp
 *
 *  Created on: Aug 4, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>
using namespace std;

int main () {
	int *int_ptr;
	int_ptr = (int *) malloc (sizeof (int));
	*int_ptr = 9;
	cout << *int_ptr << " at " << int_ptr << endl;
	free (int_ptr);
	return 0;
}



