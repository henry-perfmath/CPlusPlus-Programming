/*
 * register_demo.cpp
 *
 *  Created on: Jul 30, 2013
 *      Author: henry
 */
//#include<iostream>
//#include<cstdio>
//using namespace std;

extern char str[256];
extern char *token[20];

void tokenize ( ) {
	register char *p;
	int index = 0;
	int counter = 0;
	p = str;
	token [index] = p;
	while (*p) { 								// not end of string
		if ( *p == ' ') { 						// whitespace
			*(token [index] + counter) = '\0';	// end of token
			counter = 0;						// initialize counter
			p++;								// advance string pointer
			token [++index] = p;				// initialize token
		} else { 								// not whitespace
			p++; 								// advance string pointer
			counter++;							// increment counter
		}
	} 											// end of string

}
