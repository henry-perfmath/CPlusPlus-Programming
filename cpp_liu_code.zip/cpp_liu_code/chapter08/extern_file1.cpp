/*
 * register_demo.cpp
 *
 *  Created on: Jul 30, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdio>
using namespace std;

char str[256];
char *token[20];

int get_milliseconds() {
	return clock() * 1000 / CLOCKS_PER_SEC;
}
void tokenize ( );
int main() {
	cout << "enter a string: ";
	gets(str);
	int n_times = 1000000000; // 1 billion
	clock_t start = get_milliseconds();

	for (int i = 0; i < n_times; i++) {
		tokenize ();
	}
	int duration = get_milliseconds() - start;
	cout << "duration = " << duration << " ms" << endl;
	return 0;
}
