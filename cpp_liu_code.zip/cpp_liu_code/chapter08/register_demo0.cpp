/*
 * register_demo0.cpp
 *
 *  Created on: Aug 4, 2013
 *      Author: henry
 */
#include<iostream>
#include<ctime>
using namespace std;

unsigned int i;
unsigned int cycle;
unsigned int max_cycles = 100000000;
int main () {
	register unsigned int j;
	long start, end;

	start = clock ();
	for (cycle = 0; cycle < 50; cycle++) {
		for (i = 0; i < max_cycles; i++);
	}
	end = clock();
	cout << "Exec time (ms) for non-register loop; ";
	cout << (end - start) * (1000 / CLOCKS_PER_SEC) << endl;

	start = clock ();
		for (cycle = 0; cycle < 50; cycle++) {
			for (j = 0; j < max_cycles; j++);
		}
		end = clock();
		cout << "Exec time (ms) for non-register loop; ";
		cout << (end - start) * (1000 / CLOCKS_PER_SEC) << endl;
}



