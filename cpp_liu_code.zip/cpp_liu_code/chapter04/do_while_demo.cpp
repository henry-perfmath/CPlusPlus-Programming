/*
 * do_while_demo.cpp
 *
 *  Created on: Jul 28, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>
#include <ctime>
using namespace std;

int main () {

	cout << "rand () generates random numbers between 0 and " << RAND_MAX << endl;
	cout << "The time is " << time (NULL) << " seconds now since Jan 1 1970" << endl;
	// initialize random seed using srand function
	srand (time(NULL));

	int r0 = rand() % 5 + 1; // generate a random integer between 1 and 5

	do {
		cout << r0 << ' ';
		r0 = rand() % 5 + 1;
	} while (r0 != 5);

	return 0;
}



