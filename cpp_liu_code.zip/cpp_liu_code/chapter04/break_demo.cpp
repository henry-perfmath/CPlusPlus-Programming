/*
 * do_while_demo.cpp
 *
 *  Created on: Jul 28, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>
#include <ctime>
using namespace std;

int main() {

	srand(time(NULL));
	int r0 = rand() % 20 + 1;

	do {
		cout << r0 << ' ';
		r0 = rand() % 20 + 1;
		if ( r0 == 10) {
			break;
		}
	} while (true);

	return 0;
}

