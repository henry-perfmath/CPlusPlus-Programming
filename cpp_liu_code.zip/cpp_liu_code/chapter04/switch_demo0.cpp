/*
 * switch_demo0.cpp
 *
 *  Created on: Jul 27, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int main () {
	int option;
	cout << "enter a 0 or 1: ";
	cin >> option;
	switch (option) {
		case 0:
			cout << "hello hello" << endl;
			break;
		case 1:
			cout << "bye bye";
			break;
		default:
			cout << "sorry. no option for " << option << endl;
	}
	return 0;
}



