/*
 * do_while_demo.cpp
 *
 *  Created on: Jul 28, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>
#include <ctime>
using namespace std;

int main () {

	for (int i = 0; i < 10; i++) {
		if (!(i % 2)) {
			continue;
		}
		cout << i << ' ';
	}

	return 0;
}



