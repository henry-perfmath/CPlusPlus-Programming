/*
 * if_demo0.cpp
 *
 *  Created on: Jul 27, 2013
 *      Author: henry
 */
#include <iostream>
#include <cstdlib>     // atoi
using namespace std;

int main() {
	int i;
	char buffer[256];

	cout << ("Enter a number: ");
	cin >> buffer;
	cout << "The value entered is " << buffer << endl;
	i = atoi(buffer);
	cout << "(" << i << " + " << i << ") = " << i + i << endl;
	return 0;
}

