/*
 * if_demo2.cpp
 *
 *  Created on: Jul 27, 2013
 *      Author: henry
 */
#include <iostream>
#include <cstdlib>     // atoi
using namespace std;

bool is_a_number(char arr[]) {
	bool a_valid_number = true;
	int i = 0;
	char ch = arr[0];

	while (ch != '\0') {
		if (ch < '0' || ch > '9') {
			a_valid_number = false;
			break;
		} else {
			ch = arr[i++];
		}
	}
	return a_valid_number;
}
int main() {
	int i;
	char buffer[256];
	cout << ("Enter a number: ");
	cin >> buffer;
	cout << "The value entered is " << buffer << endl;
	if (is_a_number(buffer)) {
		i = atoi(buffer);
		cout << "(" << i << " + " << i << ") = " << i + i << endl;
	} else {
		cout << "input is not an invalid integer. try again" << endl;
	}
	return 0;
}

