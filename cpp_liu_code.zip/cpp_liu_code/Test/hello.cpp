/*
 * hello.cpp
 *
 *  Created on: Jul 21, 2013
 *      Author: henry
 */
#include <iostream>
using namespace std;

int main()
{
    cout << "Hello World!" << endl;
    return 0;
}
