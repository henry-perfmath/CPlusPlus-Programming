/*
 * func_template_0.cpp
 *
 *  Created on: Aug 18, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

template <class T> void my_swap (T &x, T &y) {
	T tmp;
	tmp = x;
	x = y;
	y = tmp;
}
int main () {
	int i1 = 1, i2 = 2;
	double d1 = 1.1, d2 = 2.2;
	char c1 = 'a', c2 = 'b';

	cout << "\nbefore: " << i1 << ' ' << i2;
	cout << "\nbefore: " << d1 << ' ' << d2;
	cout << "\nbefore: " << c1 << ' ' << c2;

	my_swap<int> (i1, i2);
	my_swap<double> (d1, d2);
	my_swap<char> (c1, c2);

	cout << "\n\nafter: " << i1 << ' ' << i2;
	cout << "\nafter: " << d1 << ' ' << d2;
	cout << "\nafter: " << c1 << ' ' << c2;

	return 0;
}



