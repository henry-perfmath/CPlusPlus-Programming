/*
 * class_template_0.cpp
 *
 *  Created on: Aug 18, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

template <class T> class calculator {
	T t1, t2;
public:
	calculator (T t1, T t2) {
		this->t1 = t1;
		this->t2 = t2;
	}
	T add () { return (t1 + t2);}
};

int main () {
	calculator <int> i_cacl (1, 2);
	calculator <double> d_cacl (1.1, 2.2);

	cout << "\n1 + 2 = " << i_cacl.add () << endl;
	cout << "1.1 + 2.2 = " << d_cacl.add () << endl;
	return 0;
}



