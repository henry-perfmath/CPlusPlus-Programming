/*
 * abstract_1.cpp
 *
 *  Created on: Aug 13, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class base {
public:
	 virtual void f () = 0;
	 //virtual ~base () {cout << "\nbase destructor called";}
	 virtual ~base () {};
	//virtual ~base ();
};

class d1 :  public base {
public:
	void f () {
		cout << "\nf () called in d1"<< endl;
	}
	d1 () {cout << "\nd1 constructor called";}
	~d1 () {cout << "\nd1 destructor called";}
};
class d2 :  public d1 {
public:
	//void f () { cout << "\nf () called in d2"<< endl; }
};
class d3 :  public d2 {
public:
	//void f () {cout << "\nf () called in d3"<< endl;}
};

int main () {
//	base base_obj; // an object of an abstract class cannot be created
	base *p;

	d1 d1_obj;
	p = &d1_obj;
	p -> f ();

	d3 d3_obj;
	p = &d3_obj;
	p -> f ();

	return 0;
}



