/*
 * op_overloading_5.cpp
 *
 *  Created on: Aug 17, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class account {
	double balance;
	int num_access [2];
public:
	account (double balance) {
		this->balance =balance;
		num_access[0] = 0;
		num_access[1] = 0;
	}
	double get_balance () {return balance;}
	void set_balance (double balance) { this->balance = balance;}
	void show_account () {
		cout << "\nbalance: " << balance;
		cout << "\nnum_access (clerk): " << num_access [0];
		cout << "\nnum_access (online): " << num_access [1]<< endl;
	}
	int &operator[] (int i);
};

int &account::operator[] (int i) {
	return (num_access[i]);
}

int main () {
	account checking (200);
	checking.show_account ();

	checking [0]++;
	checking [0]++;

	checking [1]++;
	checking [1]++;
	checking [1]++;

	checking.show_account ();
	return 0;
}



