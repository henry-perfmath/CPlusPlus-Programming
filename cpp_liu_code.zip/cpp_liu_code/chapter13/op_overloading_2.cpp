/*
 * op_overloading_2.cpp
 *
 *  Created on: Aug 17, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class account {
	double balance;
	int num_access;
public:
	account (double balance=0, int num_access = 0) {
		this->balance =balance;
		this->num_access = num_access;
	}
	double get_balance () {return balance;}
	void set_balance (double balance) { this->balance = balance;}
	void show_account () {
		cout << "\nbalance: " << balance;
		cout << "\nnum_access: " << num_access << endl;
	}
	friend account operator+ (account accnt1, account accnt2);
	account operator= (account accnt);
};
account operator+ (account accnt1, account accnt2) {
	account temp;
	temp.balance = accnt1.balance + accnt2.balance;
	return temp;
}
account account::operator= (account accnt) {
	this->set_balance (accnt.balance);
	return *this;
}

int main () {
	account savings (500, 0), checking (200, 0), accnt0;
	savings.show_account ();
	checking.show_account ();

	account accnt1;
	accnt1 = savings + checking;
	accnt1.show_account ();
	return 0;
}



