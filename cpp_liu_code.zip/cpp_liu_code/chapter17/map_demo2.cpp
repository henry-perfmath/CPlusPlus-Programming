/*
 * map_demo2.cpp
 *
 *  Created on: Aug 31, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>
#include<map>
#include<string>
using namespace std;
string get_string (int size) {
	static string str = "01234567890qwertyuiopasdfghjklzxcvbnm";
	string random_str;
	for (int i = 0; i <  size; i++) {
	int j = rand () % 36;
		random_str += str.at (j);
	}
	return random_str;
}
int main () {
	int length = 10;
	srand(time(NULL));

	// seg 0: declare a map object
	map<string, int> m;
	pair <string, int> p;
	// seg 1: add elements using push_back function
	string my_key;
	for (int i = 0; i < length; i++) {
		string key = "key_" + get_string (5);
		if (i == 5) my_key = key;
		int value = rand() % length;
		//p.first = key;
		//p.second = value;
		p = make_pair (key, value);
		cout << p.first << " <- key | value -> " << p.second << endl;
		m.insert(p);
	}

	// seg 2: use size () function and indexing to access map
	cout <<m.size() << " elements added to map m.\n";

	// seg 3: use iterator to access list
	cout << "\naccessing map using an iterator:\n";
	map<string, int>::iterator it = m.begin();
	while (it != m.end()) {
		cout << "key = " << it->first << " value = " << it->second << endl;
		it++;
	}

	// seg 4: find value of a given key
	it = m.find (my_key);
	if (it != m.end()) {
		cout << "\nfind value of " << it->second << " for key = " << my_key << endl;
	} else {
		cout << "\nno value found for key = " << my_key << endl;
	}
	return 0;
}



