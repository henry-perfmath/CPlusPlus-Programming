/*
 * algorithm_demo0.cpp
 *
 *  Created on: Aug 31, 2013
 *      Author: henry
 */

#include <iostream>
#include <algorithm>    // binary_search, sort
#include <vector>       // vector
#include <cstdlib>		// srand, rand
using namespace std;

int main() {
	int length = 10;
	srand(time(NULL));

	// seg 0: declare a vector object for containing integers
	vector<int> vec;

	// seg 1: add elements using push_back function
	for (int i = 0; i < length; i++) {
		vec.push_back(rand() % length);
	}

	// seg 2: use size () function and indexing to access vector
	cout << vec.size() << " elements added to vec.\n";
	cout << "\naccessing vector using array indexing: ";
	for (int i = 0; i < vec.size(); i++) {
		cout << vec[i] << ' ';
	}

	// seg 3: use iterator to access vector
	cout << "\naccessing vector using an iterator: ";
	sort (vec.begin(), vec.end());
	vector<int>::iterator it = vec.begin();
	while (it != vec.end()) {
		cout << *it << ' ';
		it++;
	}

	// seg 4: search an element using binary_search
	cout << "\nbinary_searching for a 5: ";
	if (binary_search(vec.begin(), vec.end(), 5)) {
		cout << " found 5\n";
	} else {
		cout << " 5 not found.\n";
	}
	return 0;
}

