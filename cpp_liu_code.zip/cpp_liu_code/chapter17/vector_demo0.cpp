/*
 * vector_demo0.cpp
 *
 *  Created on: Aug 30, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>	// for srand and rand
#include<vector>	// for vector
using namespace std;

int main() {
	int length = 10;
	srand(time(NULL));

	// seg 0: declare a vector object
	vector<int> vec;

	// seg 1: add elements using push_back function
	for (int i = 0; i < length; i++) {
		vec.push_back(rand() % length);
	}

	// seg 2: use size () function and indexing to access vector
	cout << vec.size() << " elements added to vec.\n";
	cout << "\naccessing vector using array indexing: ";
	for (int i = 0; i < vec.size(); i++) {
		cout << vec[i] << ' ';
	}

	// seg 3: use iterator to access vector
	cout << "\naccessing vector using an iterator: ";
	vector<int>::iterator it = vec.begin();
	while (it != vec.end()) {
		cout << *it << ' ';
		it++;
	}

	// seg 4: use insert function to add a new element
	it = vec.begin() + 5;
	vec.insert(it, rand() % length);
	cout << "\nvector after inserting a new element at index 5   : ";
	for (int i = 0; i < vec.size(); i++) {
		cout << vec[i] << ' ';
	}

	// seg 5: use erase function to delete elements in range
	it = vec.begin();
	vec.erase(it + 3, it +5);
	cout << "\nvector after deleting elements indexed from 3 - 5 : ";
	for (int i = 0; i < vec.size(); i++) {
		cout << vec[i] << ' ';
	}
	return 0;
}

