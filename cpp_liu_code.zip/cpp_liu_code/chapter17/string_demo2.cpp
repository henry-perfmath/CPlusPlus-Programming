/*
 * string_demo2.cpp
 *
 *  Created on: Aug 31, 2013
 *      Author: henry
 */
#include<iostream>
#include<string>
using namespace std;

int main () {
	string str1;
	string str2 = "This is old test!";
	string str3;

	str1 = "This is new test!";
	str3 = str1 + str2;

	cout << "str1 = " << str1 << endl;
	cout << "str2 = " << str2 << endl;
	cout << "str3 = " << str3 << endl;

 	return 0;
}
