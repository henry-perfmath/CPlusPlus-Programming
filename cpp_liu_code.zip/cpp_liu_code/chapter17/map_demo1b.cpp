/*
 * map_demo1b.cpp
 *
 *  Created on: Aug 31, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>
#include<map>
using namespace std;

int main () {
	int length = 10;
	srand(time(NULL));

	// seg 0: declare a map object
	map<int, int> m;
	pair <int, int> p;
	// seg 1: add elements using push_back function
	for (int i = 0; i < length; i++) {
		int key = i;
		int value = rand() % length;
		//p.first = key;
		//p.second = value;
		p = make_pair (key, value);
		cout << p.first << " <- key | value -> " << p.second << endl;
		m.insert(p);
	}

	// seg 2: use size () function and indexing to access map
	cout <<m.size() << " elements added to map m.\n";

	// seg 3: use iterator to access map elements
	cout << "\naccessing map using an iterator:\n";
	map<int, int>::iterator it = m.begin();
	while (it != m.end()) {
		cout << "key = " << it->first << " value = " << it->second << endl;
		it++;
	}

	// seg 4: find value of a given key
	int k = 5;
	it = m.find (k);
	if (it != m.end()) {
		cout << "\nfind value of " << it->second << " for key = " << k << endl;
	} else {
		cout << "\nno value found for key = " << k << endl;
	}
	return 0;
}



