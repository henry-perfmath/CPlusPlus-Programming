/*
 * function_object_demo.cpp
 *
 *  Created on: Aug 30, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;
class functor_demo {
	int _i;
    public:
	functor_demo (int i) : _i( i ) {}
    int operator() (int j) {return _i + j;}
};

int main() {
	functor_demo add( 1 );
    int sum = add ( 2 );
    cout << sum << endl;
    return 0;
}



