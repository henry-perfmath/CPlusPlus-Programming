/*
 * mergesort.cpp
 *
 *  Created on: Sep 5, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>
using namespace std;

const int MAX_ARRAY_SIZE = 10;
// convention: m is the first index and n is the last index
void merge(int a[], int m, int mid, int n) {
	// first half
	int m1 = m, n1 = mid;

	//second half
	int m2 = mid + 1, n2 = n;

	int tmp_array[MAX_ARRAY_SIZE];	// need a temp array
	int tmp_idx = m; 				// tmp_idx begins with m

	// decide which one to copy into the tmp_array
	while((m1 <= n1) && (m2 <= n2)) {
		if (a[m1] < a[m2]) {
			tmp_array[tmp_idx++] = a[m1++];
		} else {
			tmp_array[tmp_idx++] = a[m2++];
		}
	}

	// finish off the first subarray if any left over
	while (m1 <= n1) tmp_array[tmp_idx++] = a[m1++];

	// finish off the second subarray if any left over
	while (m2 <= n2) tmp_array[tmp_idx++] = a[m2++];

	// copy the result back to the original array
	for (int i = m; i <= n; i++) a[i] = tmp_array[i];
}

void my_mergesort(int a[], int start, int end) {
	if (start < end) {
		int mid = (start + end) / 2; // mid point
		my_mergesort (a, start, mid); // sort left half
		my_mergesort (a, mid + 1, end); // sort right half
		merge (a, start, mid, end); // merge the two halves
	}
}

int main() {
	srand(time(NULL));
	int a[MAX_ARRAY_SIZE];
	for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
		a[i] = rand() % 30;
		cout << a[i] << " ";
	}
	cout << endl;

	my_mergesort(a, 0, MAX_ARRAY_SIZE -1);
	cout << "after sorting:\n";
	for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
		cout << a[i] << " ";
	}
	cout << "done\n";

	return 0;
}


