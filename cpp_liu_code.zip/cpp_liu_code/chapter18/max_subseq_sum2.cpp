/*
 * max_subseq_sum2.cpp
 *
 *  Created on: Oct 14, 2013
 *      Author: hliu
 */
#include<iostream>
#include<cstdlib>
using namespace std;

int max_subsequence_sum(const int a[], const unsigned int n) {
	int sum = 0, max_sum = 0;
	for (int next = 0; next < n; next++) {
		sum += a[next];

		if (sum > max_sum) {
			max_sum = sum;
		} else if (sum < 0) {
			sum = 0;
		}
	}
	return max_sum;
}
int main() {
	int n = 0;
	cout << "enter n: ";
	cin >> n;
	srand(time(NULL));
	int a[n];
	a[0] = -5;
	for (int i = 1; i < n; i++) {
		a[i] = 20 / 2 - rand() % 20;
	}

	for (int i = 0; i < n; i++) {
		cout << a[i] << " ";
	}
	cout << endl;
	int result = max_subsequence_sum(a, n);
	cout << "result = " << result << endl;

	return 0;
}

