/*
 * insertion_sort.cpp
 *
 *  Created on: Sep 5, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>
using namespace std;

void insertion_sort(int a[], int N);
const int MAX_ARRAY_SIZE = 10;

int main() {
	srand(time(NULL));
	int a[MAX_ARRAY_SIZE];
	for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
		a[i] = rand() % 30;
		cout << a[i] << " ";
	}
	cout << endl;

	insertion_sort(a, MAX_ARRAY_SIZE);
	cout << "after sorting:\n";
	for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
		cout << a[i] << " ";
	}
	cout << "done\n";

	return 0;
}

void insertion_sort(int a[], int N) {
	for (int unsorted = 1; unsorted < N; ++unsorted) {
		int ins = unsorted;
		int currentItem = a[unsorted];
		while (a[ins - 1] > currentItem) {
			a[ins] = a[ins - 1];
			if (ins == 0) break;
			--ins;
		}
		a[ins] = currentItem;
	}
}

