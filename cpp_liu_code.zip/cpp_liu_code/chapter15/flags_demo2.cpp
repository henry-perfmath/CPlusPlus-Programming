/*
 * flags_demo2.cpp
 *
 *  Created on: Aug 27, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int main() {
	cout.setf (ios::showpos);
	cout.setf (ios::scientific);
	cout << 99 << " " << 99.99 << endl;

	cout.precision(3);
	cout.width (9);
	cout << 99 << " " << 99.99 << endl;

	cout.fill ('#');
	cout.width (9);
	cout << 99 << " " << 99.99 << endl;
	return 0;
}

