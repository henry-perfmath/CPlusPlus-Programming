/*
 * flags_demo1.cpp
 *
 *  Created on: Aug 27, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

void unset_all_flags() {
	cout.flags((ios::fmtflags) 0x0);
}
void show_flags(const char *msg, ios::fmtflags ff) {
	cout << msg << ": ";
	int mask = 0x4000;
	while (mask) {
		if (mask & ff)
			cout << "1 ";
		else
			cout << "0 ";
		mask = mask >> 1;
	}
	cout << endl;
}
void get_flag_values(const char *flag, ios::fmtflags ff) {
	cout << flag << " (index): ";
	int bit_pos = 0;
	for (int mask = 0x1; mask <= 0x4000; mask = mask << 1) {
		if (mask & ff) {
			//cout << hex << showbase << mask << " ";
			cout << dec << showbase << bit_pos
				 << " (" << hex << showbase << mask << ") ";
		}
		bit_pos++;
	}
	cout << endl;
}
void show_flag(const char *flag, ios::fmtflags ff) {
	ios::fmtflags ff0 = cout.flags();
	// 1. unset flags
	cout.flags((ios::fmtflags) 0x0);
	// 2. set flag
	cout.setf(ff);
	ios::fmtflags ff1 = cout.flags();
	//3. show flags
	show_flags("current", cout.flags());
	// 4. compare flags
	get_flag_values(flag, ff1);
	//5. restore flags
	cout.flags(ff0);
	//6. show flags
	show_flags("default", cout.flags());
}

int main() {
	ios::fmtflags ff;
	cout << "\ndefault flags:" << endl;
	ff = cout.flags();
	show_flags("default", ff);

	cout << "\ncheck boolalpha field:\n";
	show_flag("boolalpha", ios::boolalpha);

	cout << "\ncheck showbase field:\n";
	show_flag("showbase", ios::showbase);

	cout << "\ncheck showpoint field:\n";
	show_flag("showpoint", ios::showpoint);

	cout << "\ncheck showpos field:\n";
	show_flag("showpos", ios::showpos);

	cout << "\ncheck skipws field:\n";
	show_flag("skipws", ios::skipws);

	cout << "\ncheck unitbuf field:\n";
	show_flag("unitbuf", ios::unitbuf);

	cout << "\ncheck uppercase field:\n";
	show_flag("uppercase", ios::uppercase);

	cout << "\ncheck basefield flags:\n";
	show_flag("basefield", ios::basefield);

	cout << "\ncheck adjustfield flags:\n";
	show_flag("adjustfield", ios::adjustfield);

	cout << "\ncheck floatfield flags:\n";
	show_flag("floatfield", ios::floatfield);
	return 0;
}

