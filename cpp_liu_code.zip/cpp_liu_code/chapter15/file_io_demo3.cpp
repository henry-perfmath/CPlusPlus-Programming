/*
 * file_io_demo3.cpp
 *
 *  Created on: Aug 27, 2013
 *      Author: henry
 */
#include<iostream>
#include<fstream>
using namespace std;

int main() {
	const char *in_file_name = "test_0.txt";
	const char *out_file_name = "test_3.txt";
	//create ifstream object
	ifstream in;
	in.open(in_file_name, ios::in | ios::binary);
	if (!in) {
		cout << "Error in opening the file " << in_file_name << endl;
		return -1;
	}
	//create ofstream object
	ofstream out;
	out.open(out_file_name, ios::out | ios::binary);
	if (!out) {
		cout << "Error in opening the file " << out_file_name << endl;
		return -1;
	}

	int size = 4;
	char *buffer = new char [size];

	while (!in.eof()) {
		in.read(buffer, size);
		for (int i = 0; i < in.gcount(); i++)
			cout << buffer[i];
		out.write(buffer, in.gcount());
	}

	delete[] buffer;
	in.close();
	out.close();
	return 0;
}

