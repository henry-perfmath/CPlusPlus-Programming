/*
 * manip_demo.cpp
 *
 *  Created on: Aug 27, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

ostream &dec_showbase (ostream &os) {
	os << dec << showbase;
	return os;
}
ostream &hex_showbase (ostream &os) {
	os << hex << showbase;
	return os;
}
istream &skip_ws (istream &is) {
	is >> ws;
	return is;
}
int main () {
	int i;
	cin >> skip_ws >> i;
	cout << hex_showbase << i << endl;
	cout << dec_showbase << i << endl;
	return 0;
}



