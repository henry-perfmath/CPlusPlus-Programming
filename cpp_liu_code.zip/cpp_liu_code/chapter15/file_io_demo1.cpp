/*
 * file_io_demo1.cpp
 *
 *  Created on: Aug 27, 2013
 *      Author: henry
 */
#include<iostream>
#include<fstream>
using namespace std;

int main () {
	const char *out_file_name = "test_1.txt";
	ofstream out;
	out.open (out_file_name);
	//out.open (out_file_name, ios::app);
	if (!out) {
		cout << "Error in opening the file " << out_file_name << endl;
		return -1;
	}
	out << "This is another test!!";
	out.close ();
	return 0;
}



