/*
 * flags_demo0.cpp
 *
 *  Created on: Aug 26, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int main () {
	bool is_true, is_false;
	is_true = true;
	is_false = false;
	cout << is_true << " " << is_false << endl;

	cout.setf (ios::boolalpha);
	cout << is_true << " " << is_false << endl;
	// set hex as the base
	cout.setf (ios::hex, ios::basefield);

	// enable uppercase and showbase
	cout.setf (ios::uppercase | ios::showbase);
	cout << 1500 << '\n';

	//disable showbase and uppercase
	cout.unsetf (ios::showbase | ios::uppercase);
	cout << 1500 << '\n';

	//reset base to decimal
	cout.setf (ios::dec, ios::basefield);
	cout << 1500 << '\n';

	return 0;
}



