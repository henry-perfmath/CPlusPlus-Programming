/*
 * static_cast_example.cpp
 *
 *  Created on: Mar 2, 2018
 *      Author: henryliu
 */

#include <iostream>
using namespace std;

int main() {
  int j = 41;
  int v = 4;
  float m = j/v;
  //float d = static_cast<float>(j)/v;
  float d = (float) (j) / v;
  cout << "m = " << m << endl;
  cout << "d = " << d << endl;
}
